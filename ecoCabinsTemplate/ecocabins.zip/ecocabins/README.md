ecoCabins
Digital Agency Services WordPress Theme
----------------------------------------

Created : 24/05/2021
By : shahadat
Email : mshossain509@gmail.com

Thank you for visiting ecoCabins theme!


Please follow the steps to setup ecoCabins theme
---------------------------------------------------

step 1. Setup a WordPress environment
step 2. Go to Appearance->Theme
step 3. Click upload theme
step 4. Select ecocabins.zip
step 5. Click install now
step 6. Active the theme
step 7. Create 7 pages with named: Modellen, Kopen, Huren, NieUws, Button, Cookies, Privacybeleid by
==> Pages->Add New
step 9. Create two menus
==> Appearance->Menus->Create a new menu->Menu Name->(**give a menu name**)->(**select your desired pages from left Add menu items table**)->check Display location->Save menu
step 10. Go to Appearance->Customize->Site Identity->Select logo->(**upload/select logo image**)->hit Select button in bottom right corner->Skip cropping->Publish
step 11. Go to Appearance->Customize->Site Identity->Site title->write your title
step 12. Go to appearance->Customize->Site Identity->Tagline->Write your Tagline

You are done! Visit your site.
