// Importing sass file
import '../sass/app.scss';

// Importing jQuery
window.$ = require('jquery');

// Importing bootstrap specific plugins
import bootstrap from 'bootstrap';

// Magnific Popup
require('./jquery.magnific-popup.min');

// Custom js
require('./script');

